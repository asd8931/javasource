
public class p279_13 {
	String name;
	String id;
	String password;
	int age;
}
