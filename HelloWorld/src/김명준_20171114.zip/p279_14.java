
public class p279_14 {
	String name;
	String id;
	String password;
	int age;
	
	p279_14(String name, String id)
	{
		this.name = name;
		this.id = id;
	}
}
