
public class p281_16 {
	void println(int temp)
	{
		System.out.println(temp);
	}
	
	void println(boolean temp)
	{
		System.out.println(temp);
	}
	
	void println(double temp)
	{
		System.out.println(temp);
	}

	void println(String temp)
	{
		System.out.println(temp);
	}
}
