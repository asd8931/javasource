
public class p281_17 {
	static void println(int temp)
	{
		System.out.println(temp);
	}
	
	static void println(boolean temp)
	{
		System.out.println(temp);
	}
	
	static void println(double temp)
	{
		System.out.println(temp);
	}

	static void println(String temp)
	{
		System.out.println(temp);
	}
}
